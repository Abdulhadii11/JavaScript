// create variables containing strings
//Use an array to hold the value of the quotes




