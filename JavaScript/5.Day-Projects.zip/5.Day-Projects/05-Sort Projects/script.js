
const arrCase1 = [false, 100, [24, 33], "💩", 55, "🥵", null, 45, "Sanyia", 66, "James", 23];
const arrCase2 = ["28", 100, 60, "Elamin", 55, "75", "🍕"];
  

function sortArray(arr){
  
}




/* ======= TESTS ===== */

function testArrays(a, b) {
  
}


