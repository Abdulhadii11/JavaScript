"use strict";

const patisserie = {
  bananaCaramel: {
    stock: 3,
    price: 9.99,
  },
  contessa: {
    stock: 5,
    price: 7.99,
  },
  concorde: {
    stock: 11,
    price: 22.99,
  },
  mouseCake: {
    stock: 8,
    price: 16.99,
  },
  confettiSuprise: {
    stock: 9,
    price: 14.99,
  },
};

const cakeType = document.getElementById('cakeSelect');
const orderAmount = document.getElementById('cakeAmount');
const orderBtn = document.getElementById('submit_btn');


const checkOrder = (order) => {
  
    //setTimeout


};



const payment = (resolvedValueArray) => {
  
  //setTimeout
  
}

const stockControl = (resolvedValueArray) => {
  
    //setTimeout

  }



orderBtn.onclick = ()=>{
  // let order = ['contessa', 2];   // sample order template


  //then
  //catch  

}