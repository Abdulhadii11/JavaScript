
const imgContainer = document.querySelector(".images");

const createImage = function (imgPath) {
  
  

}




//call createImage with then and catch



// create a wait function
const waitFor = function (second) {


}