
const btn = document.querySelector(".btn-country");
const countriesContainer = document.querySelector(".countries");
const latitudeInput = document.querySelector("#latitude");
const longitudeInput = document.querySelector("#longitude");

const apiKey = "";  // take yours !!!

const whereAmI = function (lat, lng) {
  
};


btn.addEventListener("click", displayCountry);
